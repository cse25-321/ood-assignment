import java.sql.*;

public final class UserDAO {
    public User authenticate(Connection connection, String username, char[] password)
            throws SQLException {
        try (PreparedStatement statement =
                connection.prepareStatement("SELECT * FROM users WHERE username=?")) {
            statement.setString(1, username);
            try (ResultSet result = statement.executeQuery()) {
                if (!result.next()
                        || !Passwords.verify(password, result.getString("password_hash")))
                    throw new IllegalArgumentException("Username or password is incorrect.");
                return new User(
                        result.getLong("id"),
                        result.getString("username"),
                        result.getString("role"),
                        result.getObject("customer_id", Long.class));
            }
        }
    }

    public void create(
            Connection connection, String username, char[] password, String role, Long customerId)
            throws SQLException {
        username = Customer.required(username, "Username");
        if (!username.matches("[A-Za-z0-9._-]{3,40}"))
            throw new IllegalArgumentException(
                    "Username must contain 3–40 letters, numbers, dots, underscores or hyphens.");
        if (password.length < 8)
            throw new IllegalArgumentException("Password must contain at least eight characters.");
        try (PreparedStatement statement =
                connection.prepareStatement(
                        "INSERT INTO users(username,password_hash,role,customer_id)"
                                + " VALUES(?,?,?,?)")) {
            statement.setString(1, username);
            statement.setString(2, Passwords.hash(password));
            statement.setString(3, role);
            if (customerId == null) statement.setNull(4, Types.BIGINT);
            else statement.setLong(4, customerId);
            statement.executeUpdate();
        }
    }
}
