import javafx.geometry.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.util.function.BiConsumer;

public final class LoginView extends HBox {
    public LoginView(BiConsumer<String, char[]> login) {
        getStyleClass().add("login-root");
        setAlignment(Pos.CENTER);
        VBox brand = new VBox(22);
        brand.getStyleClass().add("login-brand");
        brand.setPrefWidth(480);
        brand.setMaxHeight(Double.MAX_VALUE);
        brand.setAlignment(Pos.CENTER_LEFT);
        Label logo = UI.label("PULA / BANK", "brand-logo");
        Label title = UI.label("Your next chapter\nstarts here.", "hero");
        Label intro =
                UI.label(
                        "Everyday banking. Room to grow.\n"
                                + "Manage your money with clarity and confidence.",
                        "brand-copy");
        HBox tags =
                new HBox(
                        10,
                        UI.label("SAVE", "pill"),
                        UI.label("INVEST", "pill"),
                        UI.label("GROW", "pill"));
        brand.getChildren()
                .addAll(
                        logo,
                        UI.spacer(),
                        title,
                        intro,
                        tags,
                        UI.spacer(),
                        UI.label("Built around you.  •  Botswana", "brand-foot"));
        VBox form = new VBox(20);
        form.setAlignment(Pos.CENTER_LEFT);
        form.setPadding(new Insets(60));
        form.setPrefWidth(520);
        form.setMaxWidth(560);
        TextField username = new TextField();
        username.setPromptText("Enter your username");
        username.setId("login-username");
        PasswordField password = new PasswordField();
        password.setPromptText("Enter your password");
        password.setId("login-password");
        Button submit =
                UI.button(
                        "Sign in  →",
                        "primary",
                        () -> {
                            char[] value = password.getText().toCharArray();
                            password.clear();
                            login.accept(username.getText(), value);
                        });
        submit.setId("login-submit");
        submit.setMaxWidth(Double.MAX_VALUE);
        submit.setDefaultButton(true);
        VBox demo =
                UI.card(
                        UI.label("DEMONSTRATION ACCESS", "eyebrow"),
                        UI.label(
                                "Administrator   admin / Admin2026!\n"
                                        + "Employee   employee / Staff2026!\n"
                                        + "Customer   naledi / Customer2026!",
                                "muted"));
        demo.getStyleClass().add("demo-card");
        form.getChildren()
                .addAll(
                        UI.label("WELCOME BACK", "eyebrow"),
                        UI.label("Good to see you.", "page-title"),
                        UI.label("Sign in to your banking workspace.", "muted"),
                        UI.field("Username", username),
                        UI.field("Password", password),
                        submit,
                        demo);
        getChildren().addAll(brand, form);
        HBox.setHgrow(brand, Priority.ALWAYS);
        HBox.setHgrow(form, Priority.ALWAYS);
    }
}
