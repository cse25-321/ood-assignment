import java.math.BigDecimal;
import java.sql.*;
import java.util.*;

public final class TransactionDAO {
    public void create(
            Connection connection,
            Account account,
            String type,
            BigDecimal amount,
            String reference)
            throws SQLException {
        try (PreparedStatement statement =
                connection.prepareStatement(
                        "INSERT INTO"
                            + " transactions(account_number,transaction_type,amount,balance_after,reference)"
                            + " VALUES(?,?,?,?,?)")) {
            statement.setString(1, account.getAccountNumber());
            statement.setString(2, type);
            statement.setBigDecimal(3, amount);
            statement.setBigDecimal(4, account.getBalance());
            statement.setString(5, reference);
            statement.executeUpdate();
        }
    }

    public List<Transaction> findAll(Connection connection, Long customerId) throws SQLException {
        List<Transaction> values = new ArrayList<>();
        String sql =
                "SELECT t.* FROM transactions t JOIN accounts a ON"
                        + " a.account_number=t.account_number"
                        + (customerId == null ? "" : " WHERE a.customer_id=?")
                        + " ORDER BY t.id DESC";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            if (customerId != null) statement.setLong(1, customerId);
            try (ResultSet result = statement.executeQuery()) {
                while (result.next())
                    values.add(
                            new Transaction(
                                    result.getLong("id"),
                                    result.getString("account_number"),
                                    result.getString("transaction_type"),
                                    result.getBigDecimal("amount"),
                                    result.getBigDecimal("balance_after"),
                                    result.getTimestamp("created_at").toLocalDateTime(),
                                    result.getString("reference")));
            }
        }
        return values;
    }
}
