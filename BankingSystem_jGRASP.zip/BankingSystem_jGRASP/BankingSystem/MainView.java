import javafx.collections.*;
import javafx.collections.transformation.FilteredList;
import javafx.geometry.*;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.math.BigDecimal;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.*;

public final class MainView extends BorderPane {
    public interface Actions {
        void navigate(String page);

        void openAccount();

        void money(boolean withdrawal);

        void register();

        void edit(Customer customer);

        void deleteCustomer(Customer customer);

        void changeBranch(Account account);

        void deleteAccount(Account account);

        void interest();

        void logout();
    }

    private final List<Account> accounts;
    private final List<Customer> customers;
    private final List<Transaction> transactions;
    private final Actions actions;
    private final User user;
    private final Map<Long, String> names = new HashMap<>();

    public MainView(
            User user,
            List<Account> accounts,
            List<Customer> customers,
            List<Transaction> transactions,
            String page,
            String message,
            Actions actions) {
        this.user = user;
        this.accounts = accounts;
        this.customers = customers;
        this.transactions = transactions;
        this.actions = actions;
        customers.forEach(c -> names.put(c.id(), c.fullName()));
        getStyleClass().add("workspace");
        VBox sidebar = new VBox(10);
        sidebar.getStyleClass().add("sidebar");
        sidebar.setPrefWidth(226);
        sidebar.getChildren()
                .addAll(
                        UI.label("PULA / BANK", "brand-logo"),
                        UI.label("YOUR BANKING WORKSPACE", "side-caption"));
        for (String item : List.of("Overview", "Accounts", "Move money", "Activity"))
            sidebar.getChildren().add(nav(item, page));
        if (user.isStaff()) sidebar.getChildren().add(nav("Customers", page));
        if (user.isAdmin()) sidebar.getChildren().add(nav("Monthly interest", page));
        sidebar.getChildren()
                .addAll(
                        UI.spacer(),
                        UI.label(user.username(), "side-user"),
                        UI.label(user.role(), "side-caption"),
                        UI.button("Sign out", "nav", actions::logout));
        setLeft(sidebar);
        VBox body = new VBox(22);
        body.setPadding(new Insets(30, 32, 24, 32));
        HBox top =
                new HBox(
                        12,
                        UI.label("WORKSPACE / " + page.toUpperCase(Locale.ROOT), "eyebrow"),
                        UI.spacer(),
                        UI.label(
                                java.time.LocalDate.now()
                                        .format(DateTimeFormatter.ofPattern("dd MMM yyyy")),
                                "muted"));
        top.setAlignment(Pos.CENTER_LEFT);
        HBox heading =
                new HBox(
                        12,
                        UI.label(
                                page.equals("Overview") ? "Your money, at a glance." : page,
                                "page-title"),
                        UI.spacer(),
                        UI.button("+ Open account", "primary", actions::openAccount));
        heading.setAlignment(Pos.CENTER_LEFT);
        body.getChildren().addAll(top, heading);
        if (message != null && !message.isBlank())
            body.getChildren().add(UI.label(message, "success"));
        Node content =
                switch (page) {
                    case "Accounts" -> accountPanel();
                    case "Move money" -> moneyPanel();
                    case "Activity" -> activityPanel(transactions);
                    case "Customers" -> customerPanel();
                    case "Monthly interest" -> interestPanel();
                    default -> overview();
                };
        body.getChildren().add(content);
        VBox.setVgrow(content, Priority.ALWAYS);
        setCenter(body);
    }

    private Button nav(String text, String selected) {
        return UI.button(
                text, text.equals(selected) ? "nav-active" : "nav", () -> actions.navigate(text));
    }

    private VBox overview() {
        BigDecimal total =
                accounts.stream().map(Account::getBalance).reduce(BigDecimal.ZERO, BigDecimal::add);
        HBox stats =
                new HBox(
                        16,
                        stat(
                                "TOTAL BALANCE",
                                Money.display(total),
                                "Across " + accounts.size() + " accounts",
                                "balance-card"),
                        stat(
                                "ACCOUNTS",
                                String.valueOf(accounts.size()),
                                "Savings · Investment · Cheque",
                                "card"),
                        stat(
                                "RECORDED ACTIVITY",
                                String.valueOf(transactions.size()),
                                "Deposits, withdrawals and interest",
                                "card"));
        VBox intro =
                UI.card(
                        UI.label("Make your next move.", "section-title"),
                        UI.label(
                                "Add to your savings or access funds from an eligible account.",
                                "muted"),
                        new HBox(
                                10,
                                UI.button(
                                        "Deposit funds  ↗", "primary", () -> actions.money(false)),
                                UI.button(
                                        "Withdraw funds", "secondary", () -> actions.money(true))));
        VBox recent = activityPanel(transactions.stream().limit(6).toList());
        return new VBox(20, stats, intro, recent);
    }

    private VBox stat(String title, String value, String detail, String style) {
        VBox v =
                new VBox(
                        12,
                        UI.label(title, "stat-label"),
                        UI.label(value, "stat-value"),
                        UI.label(detail, "stat-detail"));
        v.getStyleClass().addAll("stat", style);
        HBox.setHgrow(v, Priority.ALWAYS);
        v.setMaxWidth(Double.MAX_VALUE);
        return v;
    }

    private VBox accountPanel() {
        TableView<Account> table = UI.table();
        table.setId("accounts-table");
        table.getColumns().add(UI.column("Account", 160, Account::getAccountNumber));
        table.getColumns()
                .add(
                        UI.column(
                                "Owner",
                                150,
                                a -> names.getOrDefault(a.getCustomerId(), "Customer")));
        table.getColumns().add(UI.column("Type", 110, a -> a.getType().toString()));
        table.getColumns().add(UI.column("Branch", 130, Account::getBranch));
        table.getColumns().add(UI.column("Balance", 170, a -> Money.display(a.getBalance())));
        FilteredList<Account> rows =
                new FilteredList<>(FXCollections.observableArrayList(accounts));
        table.setItems(rows);
        TextField search = new TextField();
        search.setPromptText("Search account, owner or type");
        search.textProperty()
                .addListener(
                        (o, old, q) ->
                                rows.setPredicate(
                                        a ->
                                                (a.getAccountNumber()
                                                                + " "
                                                                + names.get(a.getCustomerId())
                                                                + " "
                                                                + a.getType())
                                                        .toLowerCase(Locale.ROOT)
                                                        .contains(q.toLowerCase(Locale.ROOT))));
        VBox box = UI.card(UI.label("Your accounts", "section-title"), search, table);
        VBox.setVgrow(table, Priority.ALWAYS);
        if (user.isStaff()) {
            Button edit =
                    UI.button(
                            "Change branch",
                            "secondary",
                            () -> {
                                if (table.getSelectionModel().getSelectedItem() != null)
                                    actions.changeBranch(
                                            table.getSelectionModel().getSelectedItem());
                            });
            Button delete =
                    UI.button(
                            "Delete unused account",
                            "danger",
                            () -> {
                                if (table.getSelectionModel().getSelectedItem() != null)
                                    actions.deleteAccount(
                                            table.getSelectionModel().getSelectedItem());
                            });
            edit.disableProperty().bind(table.getSelectionModel().selectedItemProperty().isNull());
            delete.disableProperty()
                    .bind(table.getSelectionModel().selectedItemProperty().isNull());
            box.getChildren().add(new HBox(10, edit, delete));
        }
        return box;
    }

    private VBox moneyPanel() {
        VBox deposit =
                UI.card(
                        UI.label("01 / DEPOSIT", "eyebrow"),
                        UI.label("Keep building.", "section-title"),
                        UI.label(
                                "Deposit into Savings, Investment or Cheque accounts. Your balance"
                                        + " and activity update together.",
                                "muted"),
                        UI.button("Make a deposit  ↗", "primary", () -> actions.money(false)));
        VBox withdraw =
                UI.card(
                        UI.label("02 / WITHDRAW", "eyebrow"),
                        UI.label("Ready when you are.", "section-title"),
                        UI.label(
                                "Withdraw from an Investment or Cheque account. Savings accounts do"
                                        + " not allow withdrawals.",
                                "muted"),
                        UI.button("Make a withdrawal  ↗", "secondary", () -> actions.money(true)));
        HBox columns = new HBox(20, deposit, withdraw);
        HBox.setHgrow(deposit, Priority.ALWAYS);
        HBox.setHgrow(withdraw, Priority.ALWAYS);
        deposit.setMaxWidth(Double.MAX_VALUE);
        withdraw.setMaxWidth(Double.MAX_VALUE);
        deposit.setPrefWidth(400);
        withdraw.setPrefWidth(400);
        return new VBox(
                20,
                columns,
                UI.card(
                        UI.label("A clear record, every time.", "section-title"),
                        UI.label(
                                "Every completed movement appears in Activity with its amount,"
                                        + " date, reference and resulting balance.",
                                "muted")));
    }

    private VBox activityPanel(List<Transaction> values) {
        TableView<Transaction> table = UI.table();
        table.setId("activity-table");
        table.getColumns()
                .add(
                        UI.column(
                                "Date",
                                145,
                                t ->
                                        t.createdAt()
                                                .format(
                                                        DateTimeFormatter.ofPattern(
                                                                "dd MMM yy HH:mm"))));
        table.getColumns().add(UI.column("Account", 150, Transaction::accountNumber));
        table.getColumns().add(UI.column("Type", 115, Transaction::type));
        table.getColumns().add(UI.column("Amount", 130, t -> Money.display(t.amount())));
        table.getColumns()
                .add(UI.column("Balance after", 145, t -> Money.display(t.balanceAfter())));
        table.getColumns().add(UI.column("Reference", 170, Transaction::reference));
        table.getItems().setAll(values);
        return UI.card(UI.label("Transaction activity", "section-title"), table);
    }

    private VBox customerPanel() {
        TableView<Customer> table = UI.table();
        table.getColumns().add(UI.column("ID", 80, c -> "C" + String.format("%04d", c.id())));
        table.getColumns().add(UI.column("Customer", 220, Customer::fullName));
        table.getColumns().add(UI.column("Address", 320, Customer::address));
        FilteredList<Customer> rows =
                new FilteredList<>(FXCollections.observableArrayList(customers));
        table.setItems(rows);
        TextField search = new TextField();
        search.setPromptText("Search customers");
        search.textProperty()
                .addListener(
                        (o, old, q) ->
                                rows.setPredicate(
                                        c ->
                                                c.toString()
                                                        .toLowerCase(Locale.ROOT)
                                                        .contains(q.toLowerCase(Locale.ROOT))));
        Button edit =
                UI.button(
                        "Edit details",
                        "secondary",
                        () -> {
                            if (table.getSelectionModel().getSelectedItem() != null)
                                actions.edit(table.getSelectionModel().getSelectedItem());
                        });
        Button delete =
                UI.button(
                        "Delete customer",
                        "danger",
                        () -> {
                            if (table.getSelectionModel().getSelectedItem() != null)
                                actions.deleteCustomer(table.getSelectionModel().getSelectedItem());
                        });
        edit.disableProperty().bind(table.getSelectionModel().selectedItemProperty().isNull());
        delete.disableProperty().bind(table.getSelectionModel().selectedItemProperty().isNull());
        return UI.card(
                new HBox(
                        12,
                        UI.label("Customer directory", "section-title"),
                        UI.spacer(),
                        UI.button("+ Register customer", "primary", actions::register)),
                search,
                table,
                new HBox(10, edit, delete));
    }

    private VBox interestPanel() {
        HBox rates =
                new HBox(
                        18,
                        stat("SAVINGS", "0.05%", "Monthly interest", "card"),
                        stat("INVESTMENT", "5%", "Monthly interest", "balance-card"),
                        stat("CHEQUE", "—", "No interest", "card"));
        VBox action =
                UI.card(
                        UI.label("Monthly interest · " + YearMonth.now(), "section-title"),
                        UI.label(
                                "Credit eligible accounts using their current balance. Each account"
                                        + " can receive one payment per month; repeat runs skip"
                                        + " payments already completed.",
                                "muted"),
                        UI.label(
                                "All payments in a run save together. If any payment fails, the"
                                        + " entire run is rolled back.",
                                "notice"),
                        UI.button(
                                "Process this month's interest  →", "primary", actions::interest));
        return new VBox(20, rates, action);
    }
}
