import java.sql.*;
import java.util.*;

public final class CustomerDAO {
    public Customer create(Connection connection, String firstName, String surname, String address)
            throws SQLException {
        Customer value = new Customer(0, firstName, surname, address);
        try (PreparedStatement statement =
                connection.prepareStatement(
                        "INSERT INTO customers(first_name,surname,address) VALUES(?,?,?)",
                        Statement.RETURN_GENERATED_KEYS)) {
            statement.setString(1, value.firstName());
            statement.setString(2, value.surname());
            statement.setString(3, value.address());
            statement.executeUpdate();
            try (ResultSet result = statement.getGeneratedKeys()) {
                result.next();
                return new Customer(
                        result.getLong(1), value.firstName(), value.surname(), value.address());
            }
        }
    }

    public List<Customer> findAll(Connection connection) throws SQLException {
        List<Customer> values = new ArrayList<>();
        try (PreparedStatement statement =
                        connection.prepareStatement("SELECT * FROM customers ORDER BY id");
                ResultSet result = statement.executeQuery()) {
            while (result.next()) values.add(map(result));
        }
        return values;
    }

    public Customer find(Connection connection, long id) throws SQLException {
        try (PreparedStatement statement =
                connection.prepareStatement("SELECT * FROM customers WHERE id=?")) {
            statement.setLong(1, id);
            try (ResultSet result = statement.executeQuery()) {
                if (!result.next()) throw new IllegalArgumentException("Customer not found.");
                return map(result);
            }
        }
    }

    public void update(Connection connection, Customer value) throws SQLException {
        try (PreparedStatement statement =
                connection.prepareStatement(
                        "UPDATE customers SET first_name=?,surname=?,address=? WHERE id=?")) {
            statement.setString(1, value.firstName());
            statement.setString(2, value.surname());
            statement.setString(3, value.address());
            statement.setLong(4, value.id());
            if (statement.executeUpdate() != 1)
                throw new IllegalArgumentException("Customer not found.");
        }
    }

    public void delete(Connection connection, long id) throws SQLException {
        try (PreparedStatement statement =
                connection.prepareStatement("DELETE FROM customers WHERE id=?")) {
            statement.setLong(1, id);
            if (statement.executeUpdate() != 1)
                throw new IllegalArgumentException("Customer not found.");
        }
    }

    private Customer map(ResultSet result) throws SQLException {
        return new Customer(
                result.getLong("id"),
                result.getString("first_name"),
                result.getString("surname"),
                result.getString("address"));
    }
}
