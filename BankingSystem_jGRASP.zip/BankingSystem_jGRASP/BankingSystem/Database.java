import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.*;

public final class Database {
    private final String url;

    public Database(String url) {
        this.url = url;
    }

    public Connection connect() throws SQLException {
        return DriverManager.getConnection(url, "sa", "");
    }

    public void initialize() {
        try (Connection connection = connect();
                Statement statement = connection.createStatement()) {
            for (String sql : Files.readString(Path.of("schema.sql")).split(";"))
                if (!sql.isBlank()) statement.execute(sql);
        } catch (Exception e) {
            throw new IllegalStateException(
                    "Cannot initialise the database. Start the application from its project"
                            + " folder.",
                    e);
        }
    }

    public static Database local() {
        try {
            Files.createDirectories(Path.of("data"));
        } catch (Exception e) {
            throw new IllegalStateException("Cannot create the data folder.", e);
        }
        return new Database("jdbc:h2:./data/banking;LOCK_TIMEOUT=10000");
    }
}
