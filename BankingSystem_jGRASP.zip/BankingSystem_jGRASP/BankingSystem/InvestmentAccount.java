import java.math.BigDecimal;
import java.math.RoundingMode;

public final class InvestmentAccount extends Account implements InterestCalculable {
    public InvestmentAccount(String number, long customerId, String branch, BigDecimal balance) {
        super(number, customerId, branch, balance);
    }

    public static void validateOpening(BigDecimal amount) {
        if (amount.compareTo(new BigDecimal("500.00")) < 0)
            throw new IllegalArgumentException(
                    "Investment accounts require an opening deposit of at least BWP 500.00.");
    }

    @Override
    public AccountType getType() {
        return AccountType.INVESTMENT;
    }

    @Override
    public void withdraw(BigDecimal amount) {
        debit(amount);
    }

    @Override
    public BigDecimal calculateInterest() {
        return getBalance().multiply(new BigDecimal("0.05")).setScale(2, RoundingMode.HALF_UP);
    }
}
