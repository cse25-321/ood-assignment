import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.util.function.Function;

public final class UI {
    private UI() {}

    public static Label label(String text, String style) {
        Label label = new Label(text);
        label.getStyleClass().add(style);
        label.setWrapText(true);
        return label;
    }

    public static Button button(String text, String style, Runnable action) {
        Button button = new Button(text);
        button.getStyleClass().add(style);
        button.setOnAction(e -> action.run());
        return button;
    }

    public static VBox field(String name, Node control) {
        if (control instanceof Region region) region.setMaxWidth(Double.MAX_VALUE);
        return new VBox(7, label(name, "field-label"), control);
    }

    public static VBox card(Node... nodes) {
        VBox card = new VBox(14, nodes);
        card.getStyleClass().add("card");
        return card;
    }

    public static Region spacer() {
        Region region = new Region();
        HBox.setHgrow(region, Priority.ALWAYS);
        VBox.setVgrow(region, Priority.ALWAYS);
        return region;
    }

    public static <T> TableColumn<T, String> column(
            String title, double width, Function<T, String> getter) {
        TableColumn<T, String> column = new TableColumn<>(title);
        column.setPrefWidth(width);
        column.setCellValueFactory(
                value -> new ReadOnlyStringWrapper(getter.apply(value.getValue())));
        return column;
    }

    public static <T> TableView<T> table() {
        TableView<T> table = new TableView<>();
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        table.setPlaceholder(label("No records to display.", "muted"));
        table.setMinHeight(220);
        VBox.setVgrow(table, Priority.ALWAYS);
        return table;
    }

    public static void error(javafx.stage.Window owner, String text) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.initOwner(owner);
        alert.setTitle("Please check your request");
        alert.setHeaderText("We couldn't complete that action");
        alert.setContentText(text);
        alert.showAndWait();
    }

    public static boolean confirm(javafx.stage.Window owner, String title, String text) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.initOwner(owner);
        alert.setTitle(title);
        alert.setHeaderText(title);
        alert.setContentText(text);
        return alert.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK;
    }
}
