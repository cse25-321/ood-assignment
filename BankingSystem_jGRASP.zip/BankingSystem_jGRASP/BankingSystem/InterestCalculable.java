import java.math.BigDecimal;

public interface InterestCalculable {
    BigDecimal calculateInterest();
}
