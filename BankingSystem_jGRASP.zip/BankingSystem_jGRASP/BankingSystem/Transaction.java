import java.math.BigDecimal;
import java.time.LocalDateTime;

public record Transaction(
        long id,
        String accountNumber,
        String type,
        BigDecimal amount,
        BigDecimal balanceAfter,
        LocalDateTime createdAt,
        String reference) {}
