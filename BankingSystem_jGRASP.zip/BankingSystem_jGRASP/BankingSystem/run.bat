@echo off
cd /d "%~dp0"
where javac >nul 2>nul
if errorlevel 1 (
  echo Java JDK 17 or newer is required. Add its bin folder to PATH.
  pause
  exit /b 1
)
if not exist out mkdir out
javac -encoding UTF-8 --release 17 --module-path lib --add-modules javafx.controls -cp "lib/h2.jar" -d out *.java
if errorlevel 1 (
  pause
  exit /b 1
)
copy /y style.css out\style.css >nul
java --module-path lib --add-modules javafx.controls -cp "out;lib/h2.jar" Main
pause
