import java.math.BigDecimal;
import java.math.RoundingMode;

public final class Money {
    private Money() {}

    public static BigDecimal amount(String value) {
        try {
            BigDecimal amount = new BigDecimal(value.trim());
            if (amount.scale() > 2)
                throw new IllegalArgumentException("Use at most two decimal places.");
            return amount.setScale(2, RoundingMode.UNNECESSARY);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Enter a valid amount, for example 250.00.");
        }
    }

    public static BigDecimal positive(BigDecimal value) {
        if (value == null || value.signum() <= 0)
            throw new IllegalArgumentException("Amount must be greater than zero.");
        if (value.compareTo(new BigDecimal("999999999999.99")) > 0)
            throw new IllegalArgumentException("Amount exceeds the supported limit.");
        return value.setScale(2, RoundingMode.UNNECESSARY);
    }

    public static String display(BigDecimal value) {
        return "BWP " + String.format(java.util.Locale.US, "%,.2f", value);
    }
}
