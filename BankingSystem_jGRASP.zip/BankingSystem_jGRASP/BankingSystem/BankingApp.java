import javafx.application.Application;
import javafx.concurrent.Task;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.time.YearMonth;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;

public final class BankingApp extends Application implements MainView.Actions {
    private Stage stage;
    private BankingController controller;
    private final ExecutorService worker =
            Executors.newSingleThreadExecutor(
                    r -> {
                        Thread t = new Thread(r, "banking-worker");
                        t.setDaemon(true);
                        return t;
                    });
    private String page = "Overview";
    private List<Account> accounts = List.of();
    private List<Customer> customers = List.of();

    private record Snapshot(
            List<Account> accounts, List<Customer> customers, List<Transaction> transactions) {}

    @Override
    public void start(Stage stage) {
        this.stage = stage;
        stage.setTitle("Pula Bank | Banking Workspace");
        stage.setMinWidth(1120);
        stage.setMinHeight(760);
        stage.setScene(new Scene(new StackPane(new ProgressIndicator()), 1240, 840));
        style();
        stage.show();
        task(
                () -> {
                    Database db = Database.local();
                    db.initialize();
                    DemoData.seed(db);
                    return new BankingController(db);
                },
                value -> {
                    controller = value;
                    showLogin();
                });
    }

    private void style() {
        stage.getScene()
                .getStylesheets()
                .setAll(getClass().getResource("/style.css").toExternalForm());
    }

    private void root(javafx.scene.Parent content) {
        stage.getScene().setRoot(content);
    }

    private void showLogin() {
        root(
                new LoginView(
                        (username, password) ->
                                task(
                                        () -> controller.login(username, password),
                                        u -> {
                                            page = "Overview";
                                            refresh("");
                                        })));
    }

    private void refresh(String message) {
        task(
                () ->
                        new Snapshot(
                                controller.accounts(),
                                controller.customers(),
                                controller.transactions()),
                data -> {
                    accounts = data.accounts();
                    customers = data.customers();
                    root(
                            new MainView(
                                    controller.getSession(),
                                    accounts,
                                    customers,
                                    data.transactions(),
                                    page,
                                    message,
                                    this));
                });
    }

    private <T> void task(Callable<T> operation, Consumer<T> success) {
        javafx.scene.Parent current = stage.getScene().getRoot();
        current.setDisable(true);
        stage.getScene().setCursor(javafx.scene.Cursor.WAIT);
        Task<T> task =
                new Task<>() {
                    @Override
                    protected T call() throws Exception {
                        return operation.call();
                    }
                };
        task.setOnSucceeded(
                e -> {
                    current.setDisable(false);
                    stage.getScene().setCursor(javafx.scene.Cursor.DEFAULT);
                    success.accept(task.getValue());
                });
        task.setOnFailed(
                e -> {
                    current.setDisable(false);
                    stage.getScene().setCursor(javafx.scene.Cursor.DEFAULT);
                    Throwable error = task.getException();
                    UI.error(
                            stage,
                            error.getMessage() == null
                                    ? "An unexpected error occurred."
                                    : error.getMessage());
                });
        worker.submit(task);
    }

    @Override
    public void navigate(String value) {
        page = value;
        refresh("");
    }

    @Override
    public void openAccount() {
        Forms.account(
                stage,
                customers,
                input ->
                        task(
                                () ->
                                        controller.openAccount(
                                                input.customerId(),
                                                input.type(),
                                                input.branch(),
                                                Money.amount(input.opening()),
                                                input.employer(),
                                                input.employerAddress()),
                                a -> {
                                    page = "Accounts";
                                    refresh(
                                            "Account "
                                                    + a.getAccountNumber()
                                                    + " opened successfully.");
                                }));
    }

    @Override
    public void money(boolean withdrawal) {
        Forms.money(
                stage,
                accounts,
                withdrawal,
                input ->
                        task(
                                () ->
                                        controller.transact(
                                                input.number(),
                                                Money.amount(input.amount()),
                                                input.withdrawal(),
                                                input.reference()),
                                a ->
                                        refresh(
                                                (withdrawal ? "Withdrawal" : "Deposit")
                                                        + " completed. New balance: "
                                                        + Money.display(a.getBalance()))));
    }

    @Override
    public void register() {
        Forms.customer(
                stage,
                null,
                input ->
                        task(
                                () ->
                                        controller.register(
                                                input.first(),
                                                input.surname(),
                                                input.address(),
                                                input.username(),
                                                input.password()),
                                c -> refresh(c.fullName() + " registered successfully.")));
    }

    @Override
    public void edit(Customer customer) {
        Forms.customer(
                stage,
                customer,
                input ->
                        task(
                                () -> {
                                    controller.updateCustomer(
                                            new Customer(
                                                    customer.id(),
                                                    input.first(),
                                                    input.surname(),
                                                    input.address()));
                                    return true;
                                },
                                ok -> refresh("Customer details updated.")));
    }

    @Override
    public void deleteCustomer(Customer customer) {
        if (UI.confirm(
                stage,
                "Delete customer?",
                "Delete "
                        + customer.fullName()
                        + " and their login? This is only allowed when they have no accounts."))
            task(
                    () -> {
                        controller.deleteCustomer(customer.id());
                        return true;
                    },
                    ok -> refresh("Customer deleted."));
    }

    @Override
    public void changeBranch(Account account) {
        TextInputDialog d = new TextInputDialog(account.getBranch());
        d.initOwner(stage);
        d.setTitle("Change branch");
        d.setHeaderText(account.getAccountNumber());
        d.setContentText("Branch:");
        d.showAndWait()
                .ifPresent(
                        branch ->
                                task(
                                        () -> {
                                            controller.changeBranch(
                                                    account.getAccountNumber(), branch);
                                            return true;
                                        },
                                        ok -> refresh("Account branch updated.")));
    }

    @Override
    public void deleteAccount(Account account) {
        if (UI.confirm(
                stage,
                "Delete unused account?",
                "Only a zero-balance account with no financial history can be deleted."))
            task(
                    () -> {
                        controller.deleteAccount(account.getAccountNumber());
                        return true;
                    },
                    ok -> refresh("Unused account deleted."));
    }

    @Override
    public void interest() {
        if (UI.confirm(
                stage,
                "Process monthly interest?",
                "Credit Savings at 0.05% and Investment at 5% for "
                        + YearMonth.now()
                        + "? Already-paid accounts will be skipped."))
            task(
                    () -> controller.payInterest(YearMonth.now()),
                    result ->
                            refresh(
                                    "Processed "
                                            + result.paid()
                                            + " accounts · skipped "
                                            + result.skipped()
                                            + " · interest credited: "
                                            + Money.display(result.total())));
    }

    @Override
    public void logout() {
        controller.logout();
        showLogin();
    }

    @Override
    public void stop() {
        worker.shutdownNow();
    }
}
