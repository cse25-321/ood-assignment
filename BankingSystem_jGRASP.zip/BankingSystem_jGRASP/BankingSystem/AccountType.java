public enum AccountType {
    SAVINGS("Savings"),
    INVESTMENT("Investment"),
    CHEQUE("Cheque");
    private final String label;

    AccountType(String label) {
        this.label = label;
    }

    @Override
    public String toString() {
        return label;
    }
}
