import java.math.BigDecimal;

public abstract class Account {
    private final String accountNumber;
    private final long customerId;
    private final String branch;
    private BigDecimal balance;

    protected Account(String accountNumber, long customerId, String branch, BigDecimal balance) {
        this.accountNumber = Customer.required(accountNumber, "Account number");
        if (customerId <= 0) throw new IllegalArgumentException("An account must have a customer.");
        this.customerId = customerId;
        this.branch = Customer.required(branch, "Branch");
        if (balance == null || balance.signum() < 0)
            throw new IllegalArgumentException("Balance cannot be negative.");
        this.balance = balance.setScale(2, java.math.RoundingMode.UNNECESSARY);
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public long getCustomerId() {
        return customerId;
    }

    public String getBranch() {
        return branch;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void deposit(BigDecimal amount) {
        BigDecimal updated = balance.add(Money.positive(amount));
        if (updated.compareTo(new BigDecimal("999999999999.99")) > 0)
            throw new IllegalArgumentException("Resulting balance exceeds the supported limit.");
        balance = updated;
    }

    public void deposit(BigDecimal amount, String reference) {
        Customer.required(reference, "Reference");
        deposit(amount);
    }

    protected final void debit(BigDecimal amount) {
        Money.positive(amount);
        if (amount.compareTo(balance) > 0)
            throw new IllegalArgumentException(
                    "Insufficient funds. Available: " + Money.display(balance));
        balance = balance.subtract(amount);
    }

    public abstract void withdraw(BigDecimal amount);

    public abstract AccountType getType();

    @Override
    public String toString() {
        return accountNumber + " · " + getType() + " · " + Money.display(balance);
    }
}
