import java.math.BigDecimal;
import java.sql.*;
import java.time.YearMonth;
import java.util.*;

public final class BankingController {
    private final Database database;
    private final CustomerDAO customers = new CustomerDAO();
    private final AccountDAO accounts = new AccountDAO();
    private final TransactionDAO transactions = new TransactionDAO();
    private final UserDAO users = new UserDAO();
    private User session;

    public BankingController(Database database) {
        this.database = database;
    }

    public User getSession() {
        return session;
    }

    public User login(String username, char[] password) {
        session = null;
        try {
            session =
                    work(
                            c ->
                                    users.authenticate(
                                            c, Customer.required(username, "Username"), password));
            return session;
        } finally {
            Arrays.fill(password, '\0');
        }
    }

    public void logout() {
        session = null;
    }

    private void signedIn() {
        if (session == null) throw new IllegalStateException("Please sign in first.");
    }

    private void staff() {
        signedIn();
        if (!session.isStaff())
            throw new IllegalArgumentException("This action requires a bank employee.");
    }

    private void admin() {
        signedIn();
        if (!session.isAdmin())
            throw new IllegalArgumentException("Only an administrator can run monthly interest.");
    }

    private void access(Account account) {
        signedIn();
        if (!session.isStaff() && !Objects.equals(session.customerId(), account.getCustomerId()))
            throw new IllegalArgumentException("You cannot access another customer's account.");
    }

    private Long scope() {
        signedIn();
        return session.isStaff() ? null : session.customerId();
    }

    public List<Account> accounts() {
        Long id = scope();
        return work(c -> accounts.findAll(c, id));
    }

    public List<Transaction> transactions() {
        Long id = scope();
        return work(c -> transactions.findAll(c, id));
    }

    public List<Customer> customers() {
        signedIn();
        return work(
                c ->
                        session.isStaff()
                                ? customers.findAll(c)
                                : List.of(customers.find(c, session.customerId())));
    }

    public Customer register(
            String first, String surname, String address, String username, char[] password) {
        staff();
        try {
            return work(
                    c -> {
                        Customer customer = customers.create(c, first, surname, address);
                        users.create(c, username, password, "CUSTOMER", customer.id());
                        return customer;
                    });
        } finally {
            Arrays.fill(password, '\0');
        }
    }

    public void updateCustomer(Customer value) {
        staff();
        work(
                c -> {
                    customers.update(c, value);
                    return null;
                });
    }

    public void deleteCustomer(long id) {
        staff();
        work(
                c -> {
                    if (!accounts.findAll(c, id).isEmpty())
                        throw new IllegalArgumentException(
                                "Customers with accounts cannot be deleted. Financial history must"
                                        + " be retained.");
                    try (PreparedStatement s =
                            c.prepareStatement("DELETE FROM users WHERE customer_id=?")) {
                        s.setLong(1, id);
                        s.executeUpdate();
                    }
                    customers.delete(c, id);
                    return null;
                });
    }

    public Account openAccount(
            long customerId,
            AccountType type,
            String branch,
            BigDecimal opening,
            String employer,
            String employerAddress) {
        signedIn();
        if (!session.isStaff() && !Objects.equals(session.customerId(), customerId))
            throw new IllegalArgumentException("You can only open your own account.");
        if (type == null) throw new IllegalArgumentException("Select an account type.");
        if (opening == null || opening.signum() < 0)
            throw new IllegalArgumentException("Opening deposit cannot be negative.");
        if (type == AccountType.INVESTMENT) InvestmentAccount.validateOpening(opening);
        return work(
                c -> {
                    customers.find(c, customerId);
                    String number =
                            "BW"
                                    + UUID.randomUUID()
                                            .toString()
                                            .replace("-", "")
                                            .substring(0, 12)
                                            .toUpperCase(Locale.ROOT);
                    Account a =
                            switch (type) {
                                case SAVINGS ->
                                        new SavingsAccount(
                                                number, customerId, branch, new BigDecimal("0.00"));
                                case INVESTMENT ->
                                        new InvestmentAccount(
                                                number, customerId, branch, new BigDecimal("0.00"));
                                case CHEQUE ->
                                        new ChequeAccount(
                                                number,
                                                customerId,
                                                branch,
                                                new BigDecimal("0.00"),
                                                employer,
                                                employerAddress);
                            };
                    if (opening.signum() > 0) a.deposit(opening);
                    accounts.create(c, a);
                    if (opening.signum() > 0)
                        transactions.create(c, a, "DEPOSIT", opening, "Opening deposit");
                    return a;
                });
    }

    public Account transact(
            String number, BigDecimal amount, boolean withdrawal, String reference) {
        signedIn();
        Money.positive(amount);
        String memo =
                reference == null || reference.isBlank()
                        ? (withdrawal ? "Cash withdrawal" : "Cash deposit")
                        : reference.trim();
        if (memo.length() > 160)
            throw new IllegalArgumentException("Reference must be 160 characters or fewer.");
        return work(
                c -> {
                    Account a = accounts.find(c, number, true);
                    access(a);
                    if (withdrawal) a.withdraw(amount);
                    else a.deposit(amount, memo);
                    accounts.update(c, a);
                    transactions.create(c, a, withdrawal ? "WITHDRAWAL" : "DEPOSIT", amount, memo);
                    return a;
                });
    }

    public void changeBranch(String number, String branch) {
        staff();
        String value = Customer.required(branch, "Branch");
        if (value.length() > 100)
            throw new IllegalArgumentException("Branch must be 100 characters or fewer.");
        work(
                c -> {
                    accounts.find(c, number, true);
                    try (PreparedStatement s =
                            c.prepareStatement(
                                    "UPDATE accounts SET branch=? WHERE account_number=?")) {
                        s.setString(1, value);
                        s.setString(2, number);
                        s.executeUpdate();
                    }
                    return null;
                });
    }

    public void deleteAccount(String number) {
        staff();
        work(
                c -> {
                    accounts.delete(c, number);
                    return null;
                });
    }

    public record InterestResult(int paid, int skipped, BigDecimal total) {}

    public InterestResult payInterest(YearMonth period) {
        admin();
        if (period == null || !period.equals(YearMonth.now()))
            throw new IllegalArgumentException(
                    "Interest can only be processed for the current month.");
        return work(
                c -> {
                    int paid = 0, skipped = 0;
                    BigDecimal total = new BigDecimal("0.00");
                    for (Account listed : accounts.findAll(c, null)) {
                        if (!(listed instanceof InterestCalculable)) continue;
                        Account a = accounts.find(c, listed.getAccountNumber(), true);
                        try (PreparedStatement s =
                                c.prepareStatement(
                                        "SELECT 1 FROM interest_payments WHERE account_number=? AND"
                                                + " period=?")) {
                            s.setString(1, a.getAccountNumber());
                            s.setString(2, period.toString());
                            try (ResultSet r = s.executeQuery()) {
                                if (r.next()) {
                                    skipped++;
                                    continue;
                                }
                            }
                        }
                        BigDecimal interest = ((InterestCalculable) a).calculateInterest();
                        if (interest.signum() > 0) {
                            a.deposit(interest);
                            accounts.update(c, a);
                            transactions.create(
                                    c, a, "INTEREST", interest, "Monthly interest · " + period);
                        }
                        try (PreparedStatement s =
                                c.prepareStatement(
                                        "INSERT INTO"
                                                + " interest_payments(account_number,period,amount)"
                                                + " VALUES(?,?,?)")) {
                            s.setString(1, a.getAccountNumber());
                            s.setString(2, period.toString());
                            s.setBigDecimal(3, interest);
                            s.executeUpdate();
                        }
                        total = total.add(interest);
                        paid++;
                    }
                    return new InterestResult(paid, skipped, total);
                });
    }

    private interface Operation<T> {
        T run(Connection connection) throws SQLException;
    }

    private <T> T work(Operation<T> operation) {
        try (Connection c = database.connect()) {
            c.setAutoCommit(false);
            try {
                T result = operation.run(c);
                c.commit();
                return result;
            } catch (SQLException | RuntimeException e) {
                try {
                    c.rollback();
                } catch (SQLException rollback) {
                    e.addSuppressed(rollback);
                }
                throw e;
            }
        } catch (SQLException e) {
            String state = e.getSQLState();
            if ("23505".equals(state))
                throw new IllegalArgumentException("That username or record already exists.", e);
            if ("23503".equals(state))
                throw new IllegalArgumentException(
                        "This record has linked financial history and cannot be deleted.", e);
            throw new IllegalStateException(
                    "The database operation could not be completed. No changes were saved.", e);
        }
    }
}
