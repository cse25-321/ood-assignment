import java.math.BigDecimal;
import java.sql.*;
import java.util.*;

public final class AccountDAO {
    public void create(Connection connection, Account account) throws SQLException {
        try (PreparedStatement statement =
                connection.prepareStatement("INSERT INTO accounts VALUES(?,?,?,?,?,?,?)")) {
            statement.setString(1, account.getAccountNumber());
            statement.setLong(2, account.getCustomerId());
            statement.setString(3, account.getType().name());
            statement.setString(4, account.getBranch());
            statement.setBigDecimal(5, account.getBalance());
            statement.setString(6, account instanceof ChequeAccount q ? q.getEmployerName() : null);
            statement.setString(
                    7, account instanceof ChequeAccount q ? q.getEmployerAddress() : null);
            statement.executeUpdate();
        }
    }

    public Account find(Connection connection, String number, boolean lock) throws SQLException {
        try (PreparedStatement statement =
                connection.prepareStatement(
                        "SELECT * FROM accounts WHERE account_number=?"
                                + (lock ? " FOR UPDATE" : ""))) {
            statement.setString(1, number);
            try (ResultSet result = statement.executeQuery()) {
                if (!result.next()) throw new IllegalArgumentException("Account not found.");
                return map(result);
            }
        }
    }

    public List<Account> findAll(Connection connection, Long customerId) throws SQLException {
        List<Account> values = new ArrayList<>();
        try (PreparedStatement statement =
                connection.prepareStatement(
                        "SELECT * FROM accounts"
                                + (customerId == null ? "" : " WHERE customer_id=?")
                                + " ORDER BY account_number")) {
            if (customerId != null) statement.setLong(1, customerId);
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) values.add(map(result));
            }
        }
        return values;
    }

    public void update(Connection connection, Account account) throws SQLException {
        try (PreparedStatement statement =
                connection.prepareStatement(
                        "UPDATE accounts SET balance=?,branch=? WHERE account_number=?")) {
            statement.setBigDecimal(1, account.getBalance());
            statement.setString(2, account.getBranch());
            statement.setString(3, account.getAccountNumber());
            if (statement.executeUpdate() != 1)
                throw new IllegalArgumentException("Account not found.");
        }
    }

    public void delete(Connection connection, String number) throws SQLException {
        Account account = find(connection, number, true);
        if (account.getBalance().signum() != 0)
            throw new IllegalArgumentException(
                    "Only an unused zero-balance account can be deleted.");
        try (PreparedStatement statement =
                connection.prepareStatement("DELETE FROM accounts WHERE account_number=?")) {
            statement.setString(1, number);
            statement.executeUpdate();
        }
    }

    private Account map(ResultSet result) throws SQLException {
        String accountNumber = result.getString("account_number"),
                branch = result.getString("branch");
        long id = result.getLong("customer_id");
        BigDecimal balance = result.getBigDecimal("balance");
        return switch (AccountType.valueOf(result.getString("account_type"))) {
            case SAVINGS -> new SavingsAccount(accountNumber, id, branch, balance);
            case INVESTMENT -> new InvestmentAccount(accountNumber, id, branch, balance);
            case CHEQUE ->
                    new ChequeAccount(
                            accountNumber,
                            id,
                            branch,
                            balance,
                            result.getString("employer_name"),
                            result.getString("employer_address"));
        };
    }
}
