import java.math.BigDecimal;
import java.nio.file.*;
import java.sql.*;
import java.time.YearMonth;
import java.util.*;
import java.util.concurrent.*;

public final class IntegrationTests {
    private static int passed;
    private static BankingController app;
    private static Database db;

    private static BigDecimal money(String value) {
        return new BigDecimal(value);
    }

    private static void check(String name, boolean valid) {
        if (!valid) throw new AssertionError(name);
        passed++;
        System.out.println("PASS | " + name);
    }

    private static void reject(String name, Runnable operation) {
        try {
            operation.run();
        } catch (IllegalArgumentException | IllegalStateException e) {
            check(name, true);
            return;
        }
        throw new AssertionError(name + " was accepted");
    }

    private static Account find(String number) {
        return app.accounts().stream()
                .filter(a -> a.getAccountNumber().equals(number))
                .findFirst()
                .orElseThrow();
    }

    private static void equal(String name, BigDecimal actual, String expected) {
        check(name, actual.compareTo(money(expected)) == 0);
    }

    private static void admin() {
        app.login("admin", "Admin2026!".toCharArray());
    }

    public static void main(String[] args) throws Exception {
        db =
                new Database(
                        "jdbc:h2:mem:bank_test_"
                                + UUID.randomUUID()
                                + ";DB_CLOSE_DELAY=-1;LOCK_TIMEOUT=10000");
        db.initialize();
        DemoData.seed(db);
        app = new BankingController(db);
        reject("Unauthenticated access rejected", () -> app.accounts());
        reject("Incorrect password rejected", () -> app.login("admin", "wrong".toCharArray()));
        admin();
        check("Administrator login succeeds", app.getSession().isAdmin());
        check("Ten demonstration customers", app.customers().size() == 10);
        check(
                "Multiple accounts per customer",
                app.accounts().stream().filter(a -> a.getCustomerId() == 1).count() == 2);
        check("At least ten transactions", app.transactions().size() >= 10);
        Customer c =
                app.register(
                        "Test",
                        "Customer",
                        "Plot 1, Gaborone",
                        "testcustomer",
                        "Password2026!".toCharArray());
        check("Customer and login created", app.customers().size() == 11);
        reject(
                "Duplicate username rejected",
                () ->
                        app.register(
                                "Rollback",
                                "Customer",
                                "Address",
                                "testcustomer",
                                "Password2026!".toCharArray()));
        check("Failed registration rolls back customer", app.customers().size() == 11);
        app.updateCustomer(new Customer(c.id(), "Updated", c.surname(), "New address"));
        check(
                "Customer update persisted",
                app.customers().stream()
                        .anyMatch(v -> v.id() == c.id() && v.firstName().equals("Updated")));
        reject(
                "Investment below BWP500 rejected",
                () ->
                        app.openAccount(
                                c.id(),
                                AccountType.INVESTMENT,
                                "Gaborone",
                                money("499.99"),
                                "",
                                ""));
        reject(
                "Cheque missing employer rejected",
                () ->
                        app.openAccount(
                                c.id(), AccountType.CHEQUE, "Gaborone", money("0.00"), "", ""));
        Account saving =
                app.openAccount(c.id(), AccountType.SAVINGS, "Gaborone", money("1000.00"), "", "");
        Account investment =
                app.openAccount(
                        c.id(), AccountType.INVESTMENT, "Gaborone", money("500.00"), "", "");
        Account cheque =
                app.openAccount(
                        c.id(),
                        AccountType.CHEQUE,
                        "Maun",
                        money("100.00"),
                        "Services Ltd",
                        "Plot 2");
        equal(
                "Investment at BWP500 accepted",
                find(investment.getAccountNumber()).getBalance(),
                "500.00");
        app.transact(saving.getAccountNumber(), money("250.00"), false, "Test deposit");
        equal("Deposit balance persisted", find(saving.getAccountNumber()).getBalance(), "1250.00");
        check(
                "Deposit transaction persisted",
                app.transactions().stream()
                        .anyMatch(
                                t ->
                                        t.reference().equals("Test deposit")
                                                && t.amount().compareTo(money("250.00")) == 0));
        reject(
                "Savings withdrawal rejected",
                () -> app.transact(saving.getAccountNumber(), money("1.00"), true, "Test"));
        equal(
                "Rejected withdrawal leaves balance unchanged",
                find(saving.getAccountNumber()).getBalance(),
                "1250.00");
        app.transact(investment.getAccountNumber(), money("200.00"), true, "Cash");
        equal(
                "Investment can fall below opening minimum",
                find(investment.getAccountNumber()).getBalance(),
                "300.00");
        app.transact(cheque.getAccountNumber(), money("20.00"), true, "Cash");
        equal("Cheque withdrawal persisted", find(cheque.getAccountNumber()).getBalance(), "80.00");
        reject(
                "Overdraft rejected",
                () -> app.transact(cheque.getAccountNumber(), money("81.00"), true, "Cash"));
        reject(
                "Zero deposit rejected",
                () -> app.transact(cheque.getAccountNumber(), money("0.00"), false, "Cash"));
        reject(
                "Negative deposit rejected",
                () -> app.transact(cheque.getAccountNumber(), money("-1.00"), false, "Cash"));
        reject("Too many decimal places rejected", () -> Money.amount("1.001"));
        app.changeBranch(cheque.getAccountNumber(), "Lobatse");
        check(
                "Account update persisted",
                find(cheque.getAccountNumber()).getBranch().equals("Lobatse"));
        try (Connection cn = db.connect();
                Statement s = cn.createStatement()) {
            s.execute(
                    "ALTER TABLE transactions ADD CONSTRAINT test_failure CHECK(reference <>"
                            + " 'FAIL_TEST')");
        }
        int count = app.transactions().size();
        reject(
                "Failed transaction is rejected",
                () -> app.transact(cheque.getAccountNumber(), money("10.00"), false, "FAIL_TEST"));
        equal(
                "Failed ledger insert rolls back balance",
                find(cheque.getAccountNumber()).getBalance(),
                "80.00");
        check("Failed transaction adds no history", app.transactions().size() == count);
        try (Connection cn = db.connect();
                Statement s = cn.createStatement()) {
            s.execute("ALTER TABLE transactions DROP CONSTRAINT test_failure");
        }
        app.login("testcustomer", "Password2026!".toCharArray());
        check(
                "Customer sees only owned accounts",
                app.accounts().size() == 3
                        && app.accounts().stream().allMatch(a -> a.getCustomerId() == c.id()));
        check(
                "Customer sees only own profile",
                app.customers().size() == 1 && app.customers().get(0).id() == c.id());
        reject(
                "Cross-customer deposit rejected",
                () -> app.transact("BW10001", money("1.00"), false, "Test"));
        reject(
                "Customer cannot register others",
                () ->
                        app.register(
                                "Other",
                                "User",
                                "Address",
                                "otheruser",
                                "Password2026!".toCharArray()));
        reject("Customer cannot run interest", () -> app.payInterest(YearMonth.now()));
        reject("Customer cannot edit profiles", () -> app.updateCustomer(c));
        admin();
        app.login("employee", "Staff2026!".toCharArray());
        check("Employee can read customer directory", app.customers().size() == 11);
        reject("Employee cannot run interest", () -> app.payInterest(YearMonth.now()));
        admin();
        reject(
                "Future interest period rejected",
                () -> app.payInterest(YearMonth.now().plusMonths(1)));
        BankingController.InterestResult first = app.payInterest(YearMonth.now());
        check("Interest run processes eligible accounts", first.paid() > 0);
        equal(
                "Savings interest is 0.05 percent",
                find(saving.getAccountNumber()).getBalance(),
                "1250.63");
        equal(
                "Investment interest is 5 percent",
                find(investment.getAccountNumber()).getBalance(),
                "315.00");
        equal("Cheque earns no interest", find(cheque.getAccountNumber()).getBalance(), "80.00");
        int history = app.transactions().size();
        BankingController.InterestResult again = app.payInterest(YearMonth.now());
        check(
                "Repeat interest run skips paid accounts",
                again.paid() == 0
                        && again.skipped() == first.paid()
                        && again.total().signum() == 0);
        check("No duplicate interest transactions", app.transactions().size() == history);
        Account empty =
                app.openAccount(
                        c.id(), AccountType.CHEQUE, "Maun", money("0.00"), "Employer", "Address");
        app.deleteAccount(empty.getAccountNumber());
        check(
                "Unused zero-balance account deleted",
                app.accounts().stream()
                        .noneMatch(a -> a.getAccountNumber().equals(empty.getAccountNumber())));
        reject(
                "Funded account deletion blocked",
                () -> app.deleteAccount(cheque.getAccountNumber()));
        reject("Customer with accounts deletion blocked", () -> app.deleteCustomer(c.id()));
        Customer removable =
                app.register(
                        "Remove", "Me", "Address", "removeuser", "Password2026!".toCharArray());
        app.deleteCustomer(removable.id());
        check("Unused customer and login deleted", app.customers().size() == 11);
        Account concurrent =
                app.openAccount(
                        c.id(),
                        AccountType.CHEQUE,
                        "Gaborone",
                        money("100.00"),
                        "Employer",
                        "Address");
        ExecutorService threads = Executors.newFixedThreadPool(2);
        Callable<Boolean> withdraw =
                () -> {
                    try {
                        app.transact(
                                concurrent.getAccountNumber(),
                                money("80.00"),
                                true,
                                "Concurrent test");
                        return true;
                    } catch (IllegalArgumentException e) {
                        return false;
                    }
                };
        List<Future<Boolean>> results = threads.invokeAll(List.of(withdraw, withdraw));
        threads.shutdown();
        int successes = 0;
        for (Future<Boolean> r : results) if (r.get()) successes++;
        check("Concurrent withdrawals allow exactly one success", successes == 1);
        equal(
                "Concurrent withdrawals preserve correct balance",
                find(concurrent.getAccountNumber()).getBalance(),
                "20.00");
        app.logout();
        reject("Logout blocks further access", () -> app.transactions());
        filePersistence();
        System.out.println("RESULT | " + passed + " checks passed; 0 failed");
    }

    private static void filePersistence() throws Exception {
        Path dir = Files.createTempDirectory("pula-persistence-");
        String url = "jdbc:h2:" + dir.resolve("bank").toAbsolutePath();
        Database one = new Database(url);
        one.initialize();
        DemoData.seed(one);
        BankingController a = new BankingController(one);
        a.login("admin", "Admin2026!".toCharArray());
        a.transact("BW10001", money("12.34"), false, "Restart test");
        a.logout();
        BankingController b = new BankingController(new Database(url));
        b.login("admin", "Admin2026!".toCharArray());
        equal(
                "File balance survives reconnect",
                b.accounts().stream()
                        .filter(x -> x.getAccountNumber().equals("BW10001"))
                        .findFirst()
                        .orElseThrow()
                        .getBalance(),
                "1512.34");
        check(
                "File transaction survives reconnect",
                b.transactions().stream().anyMatch(t -> t.reference().equals("Restart test")));
        b.logout();
        Files.deleteIfExists(dir.resolve("bank.mv.db"));
        Files.deleteIfExists(dir.resolve("bank.trace.db"));
        Files.delete(dir);
    }
}
