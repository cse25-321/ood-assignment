import java.math.BigDecimal;
import java.math.RoundingMode;

public final class SavingsAccount extends Account implements InterestCalculable {
    public SavingsAccount(String number, long customerId, String branch, BigDecimal balance) {
        super(number, customerId, branch, balance);
    }

    @Override
    public AccountType getType() {
        return AccountType.SAVINGS;
    }

    @Override
    public void withdraw(BigDecimal amount) {
        throw new IllegalArgumentException("Savings accounts do not permit withdrawals.");
    }

    @Override
    public BigDecimal calculateInterest() {
        return getBalance().multiply(new BigDecimal("0.0005")).setScale(2, RoundingMode.HALF_UP);
    }
}
