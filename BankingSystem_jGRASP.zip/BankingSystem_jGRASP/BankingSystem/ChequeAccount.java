import java.math.BigDecimal;

public final class ChequeAccount extends Account {
    private final String employerName;
    private final String employerAddress;

    public ChequeAccount(
            String number,
            long customerId,
            String branch,
            BigDecimal balance,
            String employerName,
            String employerAddress) {
        super(number, customerId, branch, balance);
        this.employerName = Customer.required(employerName, "Employer name");
        this.employerAddress = Customer.required(employerAddress, "Employer address");
        if (this.employerName.length() > 160 || this.employerAddress.length() > 240)
            throw new IllegalArgumentException("Employment details are too long.");
    }

    public String getEmployerName() {
        return employerName;
    }

    public String getEmployerAddress() {
        return employerAddress;
    }

    @Override
    public AccountType getType() {
        return AccountType.CHEQUE;
    }

    @Override
    public void withdraw(BigDecimal amount) {
        debit(amount);
    }
}
