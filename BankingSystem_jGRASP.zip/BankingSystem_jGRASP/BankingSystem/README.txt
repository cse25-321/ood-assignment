BANKING SYSTEM
CSE202 Object Oriented Analysis and Design with Java

Running on Windows

1. Extract the entire folder.
2. Use a 64-bit JDK 17 or 21. Both java and javac must work in Command Prompt.
3. Double-click run.bat.

The lib folder contains JavaFX and H2 for Windows x64.
The database is created in data when the application starts.

Demonstration logins

Administrator    admin       Admin2026!
Bank employee    employee    Staff2026!
Customer         naledi      Customer2026!

The initial database contains 10 customers, 11 accounts and 11 transactions.
Naledi owns a Savings account and an Investment account.
All sample records are fictional.

Using jGRASP

Open Main.java from this folder.
Add lib/h2.jar to Settings > PATH/CLASSPATH > Workspace.
Keep this project folder on the classpath.

Under Settings > Compiler Settings, add these Compile flags.
Replace C:\BankingSystem with your actual extracted folder.

-encoding UTF-8 --module-path "C:\BankingSystem\lib" --add-modules javafx.controls

Add these Run flags before the main class name.

--module-path "C:\BankingSystem\lib" --add-modules javafx.controls

Compile and run Main.java. Keep the working directory set to this folder.
The run.bat script provides the same launch commands if your jGRASP menus differ.

Files

The Java files contain the account classes, screens, controller and JDBC DAOs.
style.css provides the JavaFX appearance.
schema.sql creates the database tables.
lib contains the required third-party libraries.
run.bat compiles and launches the application.
test.bat runs IntegrationTests.java using isolated test databases.

Account rules

Savings allows deposits, prohibits withdrawals and earns 0.05% monthly interest.
Investment requires BWP500 to open and earns 5% monthly interest.
Cheque requires employer details and supports deposits and withdrawals.
Withdrawals cannot exceed the balance.
Only the administrator can process current-month interest.
Repeated interest runs skip accounts already processed for the month.

Testing

Double-click test.bat. The test program checks login, registration, account rules,
transactions, access permissions, interest, rollback, concurrent withdrawals and
persistence. All 51 checks passed after this cleanup on OpenJDK 21, targeting
Java 17, with H2 2.3.232. Verify the Windows and jGRASP launch on your computer.

For the integration report, demonstrate a login, deposit and transaction history
entry. Explain how the view calls BankingController, the Account changes its
balance and the DAOs save the balance and ledger entry in one transaction.

Submission

Upload the source to your required GitHub repository and complete the final
presentation. The bundled JavaFX libraries target Windows. Codespaces requires
Linux JavaFX libraries and a desktop display to run the GUI.

Libraries

JavaFX 17.0.12 uses GPL v2 with the Classpath Exception.
H2 2.3.232 uses MPL 2.0 or EPL 1.0.
The original library notices are retained in the jars.
