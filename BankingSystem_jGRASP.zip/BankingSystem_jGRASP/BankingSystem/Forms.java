import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Window;

import java.util.*;
import java.util.function.Consumer;

public final class Forms {
    public record CustomerInput(
            String first, String surname, String address, String username, char[] password) {}

    public record AccountInput(
            long customerId,
            AccountType type,
            String branch,
            String opening,
            String employer,
            String employerAddress) {}

    public record MoneyInput(String number, String amount, boolean withdrawal, String reference) {}

    private Forms() {}

    private static Dialog<Void> dialog(Window owner, String title, VBox content) {
        Dialog<Void> d = new Dialog<>();
        d.initOwner(owner);
        d.setTitle(title);
        d.getDialogPane()
                .getStylesheets()
                .add(Forms.class.getResource("/style.css").toExternalForm());
        content.setPrefWidth(410);
        ScrollPane scroll = new ScrollPane(content);
        scroll.setFitToWidth(true);
        scroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scroll.setPrefViewportWidth(430);
        double screenHeight = javafx.stage.Screen.getPrimary().getVisualBounds().getHeight();
        scroll.setPrefViewportHeight(Math.max(240, Math.min(520, screenHeight - 220)));
        d.getDialogPane().setContent(scroll);
        d.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);
        d.setResizable(true);
        return d;
    }

    public static void customer(Window owner, Customer existing, Consumer<CustomerInput> submit) {
        TextField first = new TextField(existing == null ? "" : existing.firstName()),
                surname = new TextField(existing == null ? "" : existing.surname()),
                address = new TextField(existing == null ? "" : existing.address()),
                username = new TextField();
        PasswordField password = new PasswordField();
        VBox fields =
                new VBox(
                        14,
                        UI.field("First name", first),
                        UI.field("Surname", surname),
                        UI.field("Address", address));
        if (existing == null)
            fields.getChildren()
                    .addAll(
                            UI.field("Login username", username),
                            UI.field("Password · at least 8 characters", password));
        Dialog<Void> d =
                dialog(owner, existing == null ? "Register customer" : "Edit customer", fields);
        fields.getChildren()
                .add(
                        UI.button(
                                "Save customer",
                                "primary",
                                () -> {
                                    submit.accept(
                                            new CustomerInput(
                                                    first.getText(),
                                                    surname.getText(),
                                                    address.getText(),
                                                    username.getText(),
                                                    password.getText().toCharArray()));
                                    password.clear();
                                    d.close();
                                }));
        d.showAndWait();
    }

    public static void account(
            Window owner, List<Customer> customers, Consumer<AccountInput> submit) {
        ComboBox<Customer> customer = new ComboBox<>();
        customer.getItems().setAll(customers);
        if (!customers.isEmpty()) customer.getSelectionModel().selectFirst();
        ComboBox<AccountType> type = new ComboBox<>();
        type.getItems().setAll(AccountType.values());
        type.getSelectionModel().selectFirst();
        TextField branch = new TextField("Gaborone"),
                opening = new TextField("0.00"),
                employer = new TextField(),
                employerAddress = new TextField();
        VBox employment =
                new VBox(
                        12,
                        UI.field("Employer name", employer),
                        UI.field("Employer address", employerAddress));
        employment.setVisible(false);
        employment.setManaged(false);
        Label rule = UI.label("Savings · 0.05% monthly interest · no withdrawals", "notice");
        type.valueProperty()
                .addListener(
                        (o, old, value) -> {
                            employment.setVisible(value == AccountType.CHEQUE);
                            employment.setManaged(value == AccountType.CHEQUE);
                            rule.setText(
                                    switch (value) {
                                        case SAVINGS ->
                                                "Savings · 0.05% monthly interest · no withdrawals";
                                        case INVESTMENT ->
                                                "Investment · 5% monthly interest · BWP500 minimum"
                                                        + " opening deposit";
                                        case CHEQUE ->
                                                "Cheque · employed customers only · no interest";
                                    });
                        });
        VBox fields =
                new VBox(
                        14,
                        UI.field("Account owner", customer),
                        UI.field("Account type", type),
                        rule,
                        UI.field("Branch", branch),
                        UI.field("Opening deposit (BWP)", opening),
                        employment);
        Dialog<Void> d = dialog(owner, "Open an account", fields);
        fields.getChildren()
                .add(
                        UI.button(
                                "Open account",
                                "primary",
                                () -> {
                                    if (customer.getValue() == null) {
                                        UI.error(owner, "Register a customer first.");
                                        return;
                                    }
                                    submit.accept(
                                            new AccountInput(
                                                    customer.getValue().id(),
                                                    type.getValue(),
                                                    branch.getText(),
                                                    opening.getText(),
                                                    employer.getText(),
                                                    employerAddress.getText()));
                                    d.close();
                                }));
        d.showAndWait();
    }

    public static void money(
            Window owner, List<Account> accounts, boolean withdrawal, Consumer<MoneyInput> submit) {
        ComboBox<Account> account = new ComboBox<>();
        account.getItems().setAll(accounts);
        account.setMaxWidth(Double.MAX_VALUE);
        if (!accounts.isEmpty()) account.getSelectionModel().selectFirst();
        TextField amount = new TextField(), reference = new TextField();
        amount.setPromptText("0.00");
        reference.setPromptText("Optional description");
        VBox fields =
                new VBox(
                        14,
                        UI.label(
                                withdrawal
                                        ? "Withdrawals are available for Investment and Cheque"
                                                + " accounts."
                                        : "Deposits are available for every account type.",
                                "muted"),
                        UI.field("Account", account),
                        UI.field("Amount (BWP)", amount),
                        UI.field("Reference", reference));
        Dialog<Void> d = dialog(owner, withdrawal ? "Withdraw funds" : "Deposit funds", fields);
        fields.getChildren()
                .add(
                        UI.button(
                                withdrawal ? "Confirm withdrawal" : "Confirm deposit",
                                "primary",
                                () -> {
                                    if (account.getValue() == null) {
                                        UI.error(owner, "Open an account first.");
                                        return;
                                    }
                                    submit.accept(
                                            new MoneyInput(
                                                    account.getValue().getAccountNumber(),
                                                    amount.getText(),
                                                    withdrawal,
                                                    reference.getText()));
                                    d.close();
                                }));
        d.showAndWait();
    }
}
