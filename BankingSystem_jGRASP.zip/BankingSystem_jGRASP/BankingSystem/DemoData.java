import java.math.BigDecimal;
import java.sql.*;

public final class DemoData {
    private DemoData() {}

    public static void seed(Database database) {
        try (Connection c = database.connect()) {
            c.setAutoCommit(false);
            try {
                try (Statement s = c.createStatement();
                        ResultSet r = s.executeQuery("SELECT COUNT(*) FROM users")) {
                    r.next();
                    if (r.getInt(1) > 0) return;
                }
                UserDAO users = new UserDAO();
                CustomerDAO customers = new CustomerDAO();
                AccountDAO accounts = new AccountDAO();
                TransactionDAO transactions = new TransactionDAO();
                users.create(c, "admin", "Admin2026!".toCharArray(), "ADMIN", null);
                users.create(c, "employee", "Staff2026!".toCharArray(), "EMPLOYEE", null);
                String[] first = {
                    "Naledi",
                    "Kabelo",
                    "Amogelang",
                    "Thato",
                    "Lorato",
                    "Mpho",
                    "Boitumelo",
                    "Neo",
                    "Lesedi",
                    "Tshepo"
                };
                String[] last = {
                    "Molefe", "Dube", "Modise", "Kgosi", "Phiri", "More", "Mogapi", "Mokgosi",
                    "Nkosi", "Motsumi"
                };
                for (int i = 0; i < 10; i++) {
                    Customer customer =
                            customers.create(
                                    c, first[i], last[i], (20 + i) + " Acacia Road, Gaborone");
                    if (i == 0)
                        users.create(
                                c,
                                "naledi",
                                "Customer2026!".toCharArray(),
                                "CUSTOMER",
                                customer.id());
                    Account a =
                            switch (i % 3) {
                                case 0 ->
                                        new SavingsAccount(
                                                "BW1000" + (i + 1),
                                                customer.id(),
                                                "Gaborone",
                                                new BigDecimal("1500.00")
                                                        .add(new BigDecimal(i * 150)));
                                case 1 ->
                                        new InvestmentAccount(
                                                "BW1000" + (i + 1),
                                                customer.id(),
                                                "Francistown",
                                                new BigDecimal("5000.00")
                                                        .add(new BigDecimal(i * 250)));
                                default ->
                                        new ChequeAccount(
                                                "BW1000" + (i + 1),
                                                customer.id(),
                                                "Maun",
                                                new BigDecimal("2800.00")
                                                        .add(new BigDecimal(i * 100)),
                                                "Kgalagadi Services",
                                                "Plot 120, Gaborone");
                            };
                    accounts.create(c, a);
                    transactions.create(c, a, "DEPOSIT", a.getBalance(), "Opening deposit");
                }
                Account second =
                        new InvestmentAccount("BW20001", 1, "Gaborone", new BigDecimal("3000.00"));
                accounts.create(c, second);
                transactions.create(c, second, "DEPOSIT", second.getBalance(), "Opening deposit");
                c.commit();
            } catch (Exception e) {
                c.rollback();
                throw e;
            }
        } catch (Exception e) {
            throw new IllegalStateException("Unable to load demonstration records.", e);
        }
    }
}
