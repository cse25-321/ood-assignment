public record Customer(long id, String firstName, String surname, String address) {
    public Customer {
        firstName = required(firstName, "First name");
        surname = required(surname, "Surname");
        address = required(address, "Address");
        if (firstName.length() > 80 || surname.length() > 80 || address.length() > 240)
            throw new IllegalArgumentException("Customer details are too long.");
    }

    public static String required(String text, String field) {
        if (text == null || text.isBlank())
            throw new IllegalArgumentException(field + " is required.");
        return text.trim();
    }

    public String fullName() {
        return firstName + " " + surname;
    }

    @Override
    public String toString() {
        return fullName() + " · C" + String.format("%04d", id);
    }
}
