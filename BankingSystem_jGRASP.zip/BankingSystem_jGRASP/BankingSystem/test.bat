@echo off
cd /d "%~dp0"
if not exist out mkdir out
javac -encoding UTF-8 --release 17 --module-path lib --add-modules javafx.controls -cp "lib/h2.jar" -d out *.java
if errorlevel 1 (
  pause
  exit /b 1
)
java -cp "out;lib/h2.jar" IntegrationTests
set "PULA_TEST_RESULT=%ERRORLEVEL%"
pause
exit /b %PULA_TEST_RESULT%
