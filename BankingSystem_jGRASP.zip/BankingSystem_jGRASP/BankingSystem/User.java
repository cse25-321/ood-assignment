public record User(long id, String username, String role, Long customerId) {
    public boolean isStaff() {
        return role.equals("EMPLOYEE") || role.equals("ADMIN");
    }

    public boolean isAdmin() {
        return role.equals("ADMIN");
    }
}
